package com.example.harish.introslider;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.harish.introslider.R;

public class MainActivity extends AppCompatActivity {
    TextView txt;
    String s="";
    Button add,sub,mul,div,one,two,three,four,five,six,seven,eight,nine,zero,delc,point,del,eql;
    double result=0;
    int checker=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);
        txt=(TextView)findViewById(R.id.textView);
        add=(Button)findViewById(R.id.add);
        sub=(Button)findViewById(R.id.sub);
        mul=(Button)findViewById(R.id.mul);
        div=(Button)findViewById(R.id.div);
        one=(Button)findViewById(R.id.one);
        two=(Button)findViewById(R.id.two);
        three=(Button)findViewById(R.id.three);
        four=(Button)findViewById(R.id.four);
        five=(Button)findViewById(R.id.five);
        six=(Button)findViewById(R.id.six);
        seven=(Button)findViewById(R.id.seven);
        eight=(Button)findViewById(R.id.eight);
        nine=(Button)findViewById(R.id.nine);
        zero=(Button)findViewById(R.id.zero);
        point=(Button)findViewById(R.id.point);
        eql=(Button)findViewById(R.id.eql);
        del=(Button)findViewById(R.id.del);
        delc=(Button)findViewById(R.id.delc);



        add.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                if (checking(s)) {
                    s = s + '+';
                    txt.setText(s);
                } else {
                    try {
                        result = calculate(s);
                        s = Double.toString(result) + '+';
                        txt.setText(s);
                    }
                    catch (Exception e)
                    {}
                }


            }


        });
        sub.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {


                if (checking(s)) {
                    s = s + '-';
                    txt.setText(s);
                } else {
                    try {
                        result = calculate(s);
                        s = Double.toString(result) + '-';
                        txt.setText(s);
                    }
                    catch (Exception e)
                    {}
                }

            }


        });
        mul.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                if (checking(s)) {
                    s = s + '*';
                    txt.setText(s);
                } else {
                    try {
                        result = calculate(s);
                        s = Double.toString(result) + '*';
                        txt.setText(s);
                    }
                    catch (Exception e)
                    {}
                }

            }


        });
        div.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                if (checking(s)) {
                    s = s + '/';
                    txt.setText(s);
                } else {
                    try {
                        result = calculate(s);
                        s = Double.toString(result) + '/';
                        txt.setText(s);
                    }
                    catch (Exception e)
                    {}
                }

            }


        });


        one.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){

                s=s+'1';
                txt.setText(s);
            }


        });
        two.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){

                s=s+'2';
                txt.setText(s);

            }


        });
        three.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){
                s=s+'3';
                txt.setText(s);

            }


        });
        four.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){

                s=s+'4';
                txt.setText(s);

            }


        });
        five.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){

                s=s+'5';
                txt.setText(s);

            }


        });
        six.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){

                s=s+'6';
                txt.setText(s);

            }


        });
        seven.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){

                s=s+'7';
                txt.setText(s);

            }


        });
        eight.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){

                s=s+'8';
                txt.setText(s);

            }


        });
        nine.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){

                s=s+'9';
                txt.setText(s);

            }


        });
        zero.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){

                s=s+'0';
                txt.setText(s);
            }


        });
        eql.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){
                try {
                    result = calculate(s);
                    s = Double.toString(result);
                    txt.setText(s);
                }
                catch (Exception e) {
                }


            }


        });
        del.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){
                try {
                    s = s.substring(0, s.length() - 1);
                }
                catch (Exception e)
                {

                }
                txt.setText(s);
            }


        });
        delc.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){
                s="";
                txt.setText("0");


            }


        });
        point.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){

                s=s+'.';
                txt.setText(s);

            }




        });

    }
    public void onBackPressed()
    {
        checker++;
        if (checker==2) {
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_HOME);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            System.exit(1);
        }
        else
        {
            Toast.makeText(MainActivity.this,"Back Again To Exit",Toast.LENGTH_LONG).show();
        }
    }


    boolean checking(String s)
    {
        int c=0,i,l=s.length();
        char ch;
        for (i = 0; i < l; i++) {
            ch = s.charAt(i);
            if (ch == '+' || ch == '-' || ch == '/' || ch == '*')
                c++;

        }
        if (c>0)
            return false;
        else
            return true;
    }

    double calculate(String s) {
        s=s+"+";
        int i, l = s.length(), c = 0,k=0;
        char ch, ch1=' ';
        double n[] = new double[2];double result=0;
        String wrd = "";
        for (i = 0; i < l; i++) {
            ch = s.charAt(i);
            if (ch == '+' || ch == '-' || ch == '/' || ch == '*')
            {
                if (k==0) {
                    ch1 = ch;
                }
                n[c++] = Double.parseDouble(wrd);
                k++;wrd="";
            }
            else
                wrd = wrd + ch;
        }
        switch (ch1)
        {
            case '+':
                result=n[0]+n[1];
                break;
            case '-':
                result=n[0]-n[1];
                break;
            case '*':
                result=n[0]*n[1];
                break;
            case '/':
                result=n[0]/n[1];
                break;
        }
        return result;
    }
}
