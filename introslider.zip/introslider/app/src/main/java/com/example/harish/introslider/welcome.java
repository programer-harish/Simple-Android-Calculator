package com.example.harish.introslider;

import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.view.View.OnClickListener;


public class welcome extends AppCompatActivity {
    private ViewPager viewpager;
    private int []layouts;
    private  Button skp;
    private MyPagerAdapter pagerAdapter;

     int first=1;
    Intent intent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        if (first!=1)
            startmain();


        setContentView(R.layout.activity_main);
        viewpager=findViewById(R.id.viewpager);
        setSatusBarTransparent();

        skp= findViewById(R.id.button4);
        skp.setVisibility(View.GONE);

        layouts= new int[]{R.layout.slider1,R.layout.slider3};
      pagerAdapter=new MyPagerAdapter(layouts,getApplicationContext());
      viewpager.setAdapter(pagerAdapter);
      viewpager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
          @Override

          public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

          }

          @Override
          public void onPageSelected(int position) {

          }

          @Override
          public void onPageScrollStateChanged(int state) {
              skp.setVisibility(View.VISIBLE);
          }
      });

        skp.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                startmain();

            }
        });



    }
    private void startmain(){
        intent=new Intent(welcome.this,MainActivity.class);
        startActivity(intent);
       // finish();
    }
    private void setSatusBarTransparent(){
        if(Build.VERSION.SDK_INT >=21) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
            Window window=getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.TRANSPARENT);


        }

    }
}
